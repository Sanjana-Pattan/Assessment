from django.contrib import admin
from .models import *

admin.site.register((Student, Teacher, Questions))
# Register your models here.
