from django.contrib import admin
from django.urls import path
from examapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/',views.userlogin, name='login'),
    path('signup/',views.signup, name='ggc'),
    path('newquestion/',views.addquestion, name='newquestion'),
    path('listofquestions/',views.questionlist, name='listofquestion'),
    
]
