from django.db import models

# Create your models here.
class Student(models.Model):
    nameofthestudent = models.CharField(max_length=30)
    rollnoofstudent = models.CharField(max_length=30, primary_key=True)
    addressofthestudent = models.CharField(max_length=50)
    collegename = models.CharField(max_length=60)
    branchname = models.CharField(max_length=50, default = 'Engineer')

class Teacher(models.Model):
    nameoftheteacher = models.CharField(max_length=30)
    staffid = models.CharField(max_length=30, primary_key=True)
    collegename = models.CharField(max_length=60)
    branchname = models.CharField(max_length=50, default = 'Engineer')

class Questions(models.Model):
    newquestion = models.CharField(max_length=35, null=True, blank=True)
