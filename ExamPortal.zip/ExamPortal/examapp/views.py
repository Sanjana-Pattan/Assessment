from django.shortcuts import render,redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout

# Create your views here.
#Signup
def signup(request):
    if request.method == 'POST':
        # un = request.POST.get("username")
        us=request.POST.get('name')
        rn = request.POST.get("rollno")
        ad = request.POST.get("address")
        cn = request.POST.get("collegename")
        bn = request.POST.get("branchname")
        pas = request.POST.get("password")
        userObj=User.objects.create_user(us,rn,ad,cn,bn,pas)
        userObj.save()
    else:
        return render(request, "signupform.html", context={})
    return redirect("ggc")

#Login

def userlogin(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fmr = AuthenticationForm(request=request,data=request.POST)
            if fmr.is_valid():
                un = fmr.cleaned_data['username']
                up = fmr.cleaned_data['password']
                user = authenticate(username=un, password=up)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Logged in successfully!!!')
        else:
            fmr = AuthenticationForm()
        return render(request,'user.html',{'form':fmr})
    

#ADDQUESTION

def addquestion(request):
    if request.method == "POST":
        q = request.POST['question']
        ad = Questions.objects.create(Addaquestion=q)
        messages.success(request, "Question Added successfully")
        return HttpResponse("Question Added Successfully")
    return render(request, 'newquestion.html')
    


#Showing the Questions

def questionlist(request):
    ql = Questions.objects.filter()
    bit = {'questions':ql}
    return render(request, 'listofquestion.html',bit)
