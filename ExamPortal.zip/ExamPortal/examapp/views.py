from django.shortcuts import render,redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.db.models import Q
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login
from django.shortcuts import render, HttpResponseRedirect
from django.contrib import messages
from .forms import SignUpForm
from django.http import HttpResponse
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from django.utils.dateparse import parse_duration
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import redirect
from .models import *
from django.contrib import messages 
from django.contrib.auth.models import User


# Create your views here.
def signup(request):
    if request.method == "POST":
        frm = SignUpForm(request.POST)
        if frm.is_valid():
            frm.save()
            return HttpResponse("Student Created Successfully!!")
    else:
        frm = SignUpForm()
    return render(request,'signup.html',{'form':frm})

#Login

def userlogin(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            fmr = AuthenticationForm(request=request,data=request.POST)
            if fmr.is_valid():
                un = fmr.cleaned_data['username']
                up = fmr.cleaned_data['password']
                user = authenticate(username=un, password=up)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Logged in successfully!!!')
        else:
            fmr = AuthenticationForm()
        return render(request,'user.html',{'form':fmr})
    

#ADDQUESTION

def addquestion(request):
    if request.method == "POST":
        q = request.POST['question']
        ad = Questions.objects.create(newquestion=q)
        messages.success(request, "Question Added successfully")
        return HttpResponse("Question Added Successfully")
    return render(request, 'newquestion.html')
    


#Showing the Questions

def questionlist(request):
    ql = Questions.objects.filter()
    bit = {'questions':ql}
    return render(request, 'listofquestion.html',bit)
